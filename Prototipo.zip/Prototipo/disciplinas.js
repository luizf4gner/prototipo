document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("form-disciplina");
  const container = document.getElementById("disciplina-container");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const nome = document.getElementById("nome-disciplina").value.trim();
    const curso = document.getElementById("curso-disciplina").value.trim();
    const carga = document.getElementById("carga-disciplina").value.trim();

    if (!nome || !curso || !carga) {
      alert("Por favor, preencha todos os campos!");
      return;
    }

    const card = document.createElement("div");
    card.className = "disciplina-card";
    card.innerHTML = `
      <h3>${nome}</h3>
      <p>Curso: ${curso}</p>
      <p>Carga Horária: ${carga}</p>
    `;

    container.appendChild(card);

    form.reset();
  });
});