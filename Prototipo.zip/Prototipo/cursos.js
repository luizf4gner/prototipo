document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".form-adicionar");
  const container = document.querySelector(".curso-container");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const nome = form.elements["nome"].value.trim();
    const duracao = form.elements["duracao"].value.trim();
    const turno = form.elements["turno"].value.trim();

    if (!nome || !duracao || !turno) {
      alert("Preencha todos os campos!");
      return;
    }

    const novoCurso = document.createElement("div");
    novoCurso.classList.add("curso-card");

    novoCurso.innerHTML = `
      <h3>${nome}</h3>
      <p>Duração: ${duracao}</p>
      <p>Turno: ${turno}</p>
    `;

    container.appendChild(novoCurso);
    form.reset();
  });
});