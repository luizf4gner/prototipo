document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("disponibilidade-form");
  const container = document.getElementById("disponibilidade-container");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const turno = document.getElementById("turno").value.trim();
    const dias = document.getElementById("dias").value.trim();

    if (!nome || !turno || !dias) {
      alert("Por favor, preencha todos os campos!");
      return;
    }

    const card = document.createElement("div");
    card.className = "disponibilidade-card";
    card.innerHTML = `
      <h3>${nome}</h3>
      <p><strong>Turno:</strong> ${turno}</p>
      <p><strong>Dias Disponíveis:</strong> ${dias}</p>
    `;

    container.appendChild(card);
    form.reset();
  });
});