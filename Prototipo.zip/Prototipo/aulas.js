document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("aula-form");
  const container = document.getElementById("aula-container");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const disciplina = document.getElementById("disciplina").value.trim();
    const professor = document.getElementById("professor").value.trim();
    const turma = document.getElementById("turma").value.trim();
    const data = document.getElementById("data").value;

    if (!disciplina || !professor || !turma || !data) {
      alert("Preencha todos os campos!");
      return;
    }

    const card = document.createElement("div");
    card.className = "aula-card";
    card.innerHTML = `
      <h3>Disciplina: ${disciplina}</h3>
      <p>Professor: ${professor}</p>
      <p>Turma: ${turma}</p>
      <p>Data: ${data}</p>
    `;

    container.appendChild(card);
    form.reset();
  });
});