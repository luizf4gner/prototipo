document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('form-professor');
  const container = document.getElementById('professor-container');

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const nome = document.getElementById('nome-professor').value.trim();
    const disciplina = document.getElementById('disciplina-professor').value.trim();
    const turno = document.getElementById('turno-professor').value.trim();

    if (!nome || !disciplina || !turno) {
      alert('Preencha todos os campos!');
      return;
    }

    const card = document.createElement('div');
    card.className = 'professor-card';

    card.innerHTML = `
      <h3>${nome}</h3>
      <p>Disciplina: ${disciplina}</p>
      <p>Turno: ${turno}</p>
    `;

    container.appendChild(card);

    form.reset();
  });
});