document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("substituicao-form");
  const container = document.getElementById("substituicao-container");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const disciplina = document.getElementById("disciplina").value.trim();
    const professorTitular = document.getElementById("professor-titular").value.trim();
    const professorSubstituto = document.getElementById("professor-substituto").value.trim();
    const novaData = document.getElementById("nova-data").value;
    const turma = document.getElementById("turma").value.trim();

    if (!disciplina || !professorTitular || !professorSubstituto || !novaData || !turma) {
      alert("Por favor, preencha todos os campos!");
      return;
    }

    const card = document.createElement("div");
    card.className = "substituicao-card";
    card.innerHTML = `
      <h3>${disciplina} - ${turma}</h3>
      <p><strong>Data original:</strong> 15/08/2025</p>
      <p><strong>Professor titular:</strong> ${professorTitular}</p>
      <p><strong>Substituto:</strong> ${professorSubstituto}</p>
      <p><strong>Nova data:</strong> ${novaData}</p>
      <p><strong>Horário:</strong> 08:00 - 10:00</p>
    `;

    container.appendChild(card);
    form.reset();
  });
});