document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("turma-form");
  const container = document.getElementById("turma-container");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const curso = document.getElementById("curso").value.trim();
    const turno = document.getElementById("turno").value.trim();

    if (!nome || !curso || !turno) {
      alert("Preencha todos os campos!");
      return;
    }

    const card = document.createElement("div");
    card.className = "turma-card";
    card.innerHTML = `
      <h3>${nome}</h3>
      <p>Curso: ${curso}</p>
      <p>Turno: ${turno}</p>
    `;

    container.appendChild(card);
    form.reset();
  });
});